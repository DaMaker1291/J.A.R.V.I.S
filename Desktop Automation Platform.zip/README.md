
  # Desktop Automation Platform

  This is a code bundle for Desktop Automation Platform. The original project is available at https://www.figma.com/design/GQk3lKBGiPyRT7KvT0JZYZ/Desktop-Automation-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  